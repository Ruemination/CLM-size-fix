Credits
=======
  
  - Core AddOn development and initiative leader
    * [Lantis](https://github.com/lantisnt)

  - Event Sourcing library development and CLM co-design
    * [Sam Mousa](https://github.com/SamMousa)

  - Features co-development
    * [Peleccotur](https://github.com/Peleccotur)

  - Discord and ingame icons
    * Vergil#1234

  - Consultations and inputs
    * Athica#1115
    * Zh0rax#1454
    * Taid#6592